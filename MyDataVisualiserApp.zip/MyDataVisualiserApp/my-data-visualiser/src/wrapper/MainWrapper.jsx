import React, {useState} from "react";
import ChartViewer from '../component/ChartViewer';
import FileUploader from '../component/FileUploader';
import MenuDetails from '../component/MenuDetails';
import "./styles/MainWrapper.css";

const MainWrapper = () => {

    const [uploadedData, setUploadedData] = useState({});
    const [selectedMenuType, setSelectedMenuType] = useState("");

    return(
        <div className="mainWrapper" >
            <h1 id="my-app-name">My Data Visualiser</h1>
            <div className="myMenuDetails"><MenuDetails updateMenuType={setSelectedMenuType}/></div>

            {selectedMenuType === 'Upload Data' && <FileUploader setData={setUploadedData} />}
            {selectedMenuType === 'Visualize Data' 
                && Object.keys(uploadedData).length !== 0 
                && uploadedData.constructor !== Object != {} 
                && <ChartViewer data={uploadedData}/>
            }
        </div>
    );
};

export default MainWrapper;