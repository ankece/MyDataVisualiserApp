import React from "react";
import Chart from "react-apexcharts";

const chartViewer = (props) => {

    const {data} = props;

    const getPlotData = () => {

        const plotData = [];
        data.forEach(i => {
            plotData.push([i.x, i.y]);
        })        
        return plotData;
    }

    const chartDataFormat = {
          
        series: [{
          name: "SAMPLE A",
          data: getPlotData()
        }],
        options: {
          chart: {
            height: 350,
            type: 'scatter',
            zoom: {
              enabled: true,
              type: 'xy'
            }
          },
          xaxis: {
            tickAmount: 10,
            labels: {
              formatter: function(val) {
                return parseFloat(val).toFixed(1)
              }
            }
          },
          yaxis: {
            tickAmount: 7
          }
        }
      };
    
      return(
        <div id="chart">
            <Chart options={chartDataFormat.options} series={chartDataFormat.series} type="scatter" height={650} width={800}/>
      </div>
      );

}

export default chartViewer;