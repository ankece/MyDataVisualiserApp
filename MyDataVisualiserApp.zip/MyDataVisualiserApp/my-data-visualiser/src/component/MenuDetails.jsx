import React from "react";
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';

const MenuDetails = (props) => {

    const {updateMenuType} = props;

    const onClickMenuItem = (popupState, event) =>{
        updateMenuType(event.target.outerText);
        popupState.close();
    }

    return(
        <PopupState variant="popover" popupId="demo-popup-menu">
        {(popupState) => (
            <React.Fragment>
            <Button variant="contained" {...bindTrigger(popupState)}>
                Choose your action
            </Button>
            <Menu {...bindMenu(popupState)}>
                <MenuItem onClick={(event) => onClickMenuItem(popupState, event)}>Upload Data</MenuItem>
                <MenuItem onClick={(event) => onClickMenuItem(popupState, event)}>Visualize Data</MenuItem>
            </Menu>
            </React.Fragment>
        )}
        </PopupState>
    );
};

export default MenuDetails;