import React, { useState } from "react";
import {read, utils} from "xlsx";
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import "./styles/FileUploader.css";

const FileUploader = (props) => {

    const {setData} = props;

    const [fileName, setFileName] = useState();

    const handleImport = (data) => {
        const files = data.target.files;
        setFileName(files[0].name);
        if (files.length) {
            const file = files[0];
            const reader = new FileReader();
            reader.onload = (data) => {
                const wb = read(data.target.result);
                const sheets = wb.SheetNames;

                if (sheets.length) {
                    const rows = utils.sheet_to_json(wb.Sheets[sheets[0]]);
                    setData(rows);
                }
            }
            reader.readAsArrayBuffer(file);
        }
    };

    return(
        // <div className="custom-file">
        //     <tr>
        //     <th><p className="uploaded_file_name">{fileName}</p></th>
        //     <th>
        //         <input type="file" name="file" className="custom-file-input" id="inputGroupFile" required onChange={(data) => handleImport(data)} accept=".csv"/>
        //         <label className="custom-file-label" htmlFor="inputGroupFile">Choose file</label>
        //     </th>
        // </tr>
            
            
        // </div>
        <Stack direction="row" alignItems="center" spacing={2}>
            <Button variant="contained" component="label">
                Upload
                <input hidden accept=".csv" multiple type="file" onChange={(data) => handleImport(data)} />
            </Button>
        </Stack>
    );
};

export default FileUploader;