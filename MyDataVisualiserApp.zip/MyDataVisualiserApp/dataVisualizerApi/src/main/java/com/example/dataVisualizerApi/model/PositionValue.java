package com.example.dataVisualizerApi.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity(name="position_value_tbl")
public class PositionValue {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name="x_value", nullable = false)
	private String xValue;

	@Column(name="y_value", nullable = false)
	private String yValue;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "record_id")
	@JsonBackReference
	private DocRecord docRecord;
}
