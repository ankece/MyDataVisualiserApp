package com.example.dataVisualizerApi.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@Data
public class DocRecordDTO {

	private String recordName;
	private String createdBy;
	private Set<PositionValueDTO> positionValues;
}
