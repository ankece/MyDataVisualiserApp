package com.example.dataVisualizerApi.controller;

import com.example.dataVisualizerApi.dto.DocRecordDTO;
import com.example.dataVisualizerApi.model.AllRecordResponse;
import com.example.dataVisualizerApi.model.DocRecord;
import com.example.dataVisualizerApi.service.RecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/myDataVisualiser/")
public class RecordController {

	@Autowired
	private RecordService recordService;

	@PostMapping(value = "/record", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> createRecord(@RequestBody DocRecordDTO docRecord){

		log.info("Request received to create new document record");
		String response = recordService.createRecord(docRecord);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@GetMapping(value = "/records", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AllRecordResponse> getAllRecords(){

		log.info("Request received to fetch all document records");
		List<DocRecord> docRecords = recordService.getAllRecords();

		AllRecordResponse response = new AllRecordResponse();
		response.setContent(docRecords);

		return  new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping(value = "/record", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocRecord> getRecordByName(@RequestParam("recordName") String recordName){

		log.info("Request received to fetch document record by name");
		DocRecord record = recordService.getRecordByName(recordName);

		if(record == null){
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return  ResponseEntity.ok(recordService.getRecordByName(recordName));
		}
	}
}
