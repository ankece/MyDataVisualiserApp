package com.example.dataVisualizerApi.model;

import lombok.Data;

import java.util.List;

@Data
public class AllRecordResponse {

	private List<DocRecord> content;
}
