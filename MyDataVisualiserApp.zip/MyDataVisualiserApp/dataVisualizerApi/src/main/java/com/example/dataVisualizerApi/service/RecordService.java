package com.example.dataVisualizerApi.service;

import com.example.dataVisualizerApi.dto.DocRecordDTO;
import com.example.dataVisualizerApi.model.DocRecord;
import com.example.dataVisualizerApi.model.PositionValue;
import com.example.dataVisualizerApi.repository.RecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class RecordService {

	@Autowired
	private RecordRepository recordRepository;

	public String createRecord(DocRecordDTO docRecordDto){

		DocRecord docRecord = getDocRecordModelObject(docRecordDto);
		DocRecord createdDocRecord = recordRepository.save(docRecord);
		return "{\"id\": "+ createdDocRecord.getRecordId() +", \"message\":\"Record created successfully\"}";
	}

	public DocRecord getRecordByName(String recordName){
		return recordRepository.findByRecordName(recordName);
	}

	public List<DocRecord> getAllRecords(){
		return recordRepository.findAll();
	}

	private DocRecord getDocRecordModelObject(DocRecordDTO docRecordDto){

		DocRecord docRecord = new DocRecord();
		docRecord.setRecordName(docRecordDto.getRecordName());
		docRecord.setCreatedBy(docRecordDto.getRecordName());

		Set<PositionValue> positionValues = new HashSet<>();
		docRecordDto.getPositionValues().forEach(pv -> {
			PositionValue positionValue = new PositionValue();
			positionValue.setXValue(pv.getXValue());
			positionValue.setYValue(pv.getYValue());
			positionValue.setDocRecord(docRecord);
			positionValues.add(positionValue);
		});
		docRecord.setPositionValues(positionValues);

		return docRecord;
	}
}
