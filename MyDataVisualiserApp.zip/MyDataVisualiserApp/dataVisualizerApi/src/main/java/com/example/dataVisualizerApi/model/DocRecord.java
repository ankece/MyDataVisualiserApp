package com.example.dataVisualizerApi.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;
import java.util.Set;

@Getter
@Setter
@Entity(name="record_tbl")
public class DocRecord {

	@Id
	@Column(name = "record_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int recordId;

	@Column(name = "record_name")
	private String recordName;

	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_on", nullable = false, updatable = false)
	private Date createOn;

	@Column(name = "created_by")
	private String createdBy;

	@OneToMany(mappedBy = "docRecord", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JsonManagedReference
	private Set<PositionValue> positionValues;
}
