package com.example.dataVisualizerApi.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class PositionValueDTO {

	private String xValue;
	private String yValue;
}
