package com.example.dataVisualizerApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataVisualizerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataVisualizerApiApplication.class, args);
	}

}
