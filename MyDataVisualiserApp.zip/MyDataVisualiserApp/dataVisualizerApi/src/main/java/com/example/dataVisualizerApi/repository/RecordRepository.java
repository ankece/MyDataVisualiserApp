package com.example.dataVisualizerApi.repository;

import com.example.dataVisualizerApi.model.DocRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecordRepository extends JpaRepository<DocRecord, Integer> {

	public DocRecord findByRecordName(String recordName);
}
