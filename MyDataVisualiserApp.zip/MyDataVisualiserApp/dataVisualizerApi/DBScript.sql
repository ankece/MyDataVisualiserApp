
---Create Record table
create table record_tbl (record_id int primary key, record_name varchar(200), created_on date, created_by varchar(100));

---Create Position Value table
create table position_value_tbl (id int primary key, x_value varchar(100), y_value varchar(100), record_id int, constraint fk_record foreign key (record_id) references record_tbl(record_id));

